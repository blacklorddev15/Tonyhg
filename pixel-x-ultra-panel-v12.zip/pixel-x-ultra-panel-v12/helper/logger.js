// ============================================================
//   helper/logger.js  – stylish colored console output
// ============================================================
'use strict';

process.env.FORCE_COLOR = process.env.FORCE_COLOR || '3';
const chalk = require('chalk');
try { chalk.level = 3; } catch {}

const icons = {
  text:      '💬',
  image:     '🖼 ',
  video:     '🎥',
  audio:     '🎵',
  sticker:   '🌀',
  document:  '📄',
  location:  '📍',
  contact:   '👤',
  reaction:  '❤️',
  poll:      '📊',
  viewOnce:  '👁 ',
  unknown:   '❓',
};

function getMsgType(msg) {
  if (!msg) return 'unknown';
  if (msg.conversation || msg.extendedTextMessage)    return 'text';
  if (msg.imageMessage)     return 'image';
  if (msg.videoMessage)     return 'video';
  if (msg.audioMessage)     return 'audio';
  if (msg.stickerMessage)   return 'sticker';
  if (msg.documentMessage)  return 'document';
  if (msg.locationMessage)  return 'location';
  if (msg.contactMessage)   return 'contact';
  if (msg.reactionMessage)  return 'reaction';
  if (msg.pollCreationMessage) return 'poll';
  if (msg.viewOnceMessage || msg.viewOnceMessageV2) return 'viewOnce';
  return 'unknown';
}

function getMsgText(msg) {
  if (!msg) return '';
  if (msg.conversation) return msg.conversation;
  if (msg.extendedTextMessage?.text) return msg.extendedTextMessage.text;
  if (msg.imageMessage?.caption) return msg.imageMessage.caption;
  if (msg.videoMessage?.caption) return msg.videoMessage.caption;
  if (msg.documentMessage?.caption) return msg.documentMessage.caption;
  if (msg.reactionMessage?.text) return msg.reactionMessage.text;
  if (msg.pollCreationMessage?.name) return msg.pollCreationMessage.name;
  if (msg.locationMessage) {
    const lat = msg.locationMessage.degreesLatitude;
    const lon = msg.locationMessage.degreesLongitude;
    return '[' + (Number.isFinite(lat) ? lat.toFixed(4) : 'unknown') + ', ' + (Number.isFinite(lon) ? lon.toFixed(4) : 'unknown') + ']';
  }
  if (msg.contactMessage?.displayName) return msg.contactMessage.displayName;
  return '';
}

function logMessage(m, chatMeta = {}) {
  try {
    const msg     = m.message;
    let realMsg   = msg;
    const wrappers = ['ephemeralMessage','viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension'];
    for (const w of wrappers) { if (realMsg?.[w]?.message) realMsg = realMsg[w].message; }

    const type     = getMsgType(realMsg);
    const icon     = icons[type] || icons.unknown;
    const text     = getMsgText(realMsg).slice(0, 120);
    const sender   = (m.key.participant || m.key.remoteJid || '').split('@')[0].split(':')[0].replace(/\D/g,'');
    const name     = m.pushName || sender;
    const ts       = new Date(Number(m.messageTimestamp || 0) * 1000);
    const time     = ts.toLocaleTimeString('en-US', { hour12: true });
    const jid      = m.key.remoteJid || '';
    const isGroup   = jid.endsWith('@g.us');
    const isChannel = jid.endsWith('@newsletter');
    const isDM      = !isGroup && !isChannel;

    const chatLabel = isGroup
      ? chalk.magentaBright(`[GROUP: ${chatMeta.groupName || jid.split('@')[0]}]`)
      : isChannel
        ? chalk.cyanBright(`[CHANNEL: ${chatMeta.groupName || jid.split('@')[0]}]`)
        : chalk.blueBright('[DM]');

    console.log(
      chalk.gray('─'.repeat(60)) + '\n' +
      chalk.yellowBright('  PIXEL X ULTRA ') + chalk.gray('│ New Message\n') +
      chalk.gray('  sender  : ') + chalk.greenBright(name) + chalk.gray(` (${sender})\n`) +
      chalk.gray('  time    : ') + chalk.whiteBright(time) + '\n' +
      chalk.gray('  chat    : ') + chatLabel + '\n' +
      chalk.gray('  type    : ') + chalk.keyword('orange')(icon + ' ' + type) + '\n' +
      (text ? chalk.gray('  message : ') + chalk.white(text) + '\n' : '') +
      chalk.gray('─'.repeat(60))
    );
  } catch {}
}

function logInfo(label, msg) {
  console.log(chalk.cyanBright(`  [INFO]  `) + chalk.white(label) + (msg ? chalk.gray(' – ' + msg) : ''));
}
function logSuccess(label, msg) {
  console.log(chalk.greenBright(`  [OK]    `) + chalk.white(label) + (msg ? chalk.gray(' – ' + msg) : ''));
}
function logWarn(label, msg) {
  console.log(chalk.yellowBright(`  [WARN]  `) + chalk.white(label) + (msg ? chalk.gray(' – ' + msg) : ''));
}
function logError(label, msg) {
  console.log(chalk.redBright(`  [ERR]   `) + chalk.white(label) + (msg ? chalk.gray(' – ' + msg) : ''));
}
function logSession(sessionId, status) {
  const icon = status === 'connected' ? '🟢' : status === 'reconnecting' ? '🟡' : '🔴';
  console.log(chalk.gray('  session : ') + chalk.bold(sessionId) + ' ' + icon + ' ' + chalk.gray(status));
}

module.exports = { logMessage, logInfo, logSuccess, logWarn, logError, logSession, getMsgType };
