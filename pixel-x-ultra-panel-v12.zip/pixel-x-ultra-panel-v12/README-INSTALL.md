# Pixel X Ultra — panel build (install)

Drop-in overlay for a Pterodactyl server running this WhatsApp bot.
Everything here is the exact code currently running on server `Blacklord 👽`.

## Contents

| Path | What it is |
|---|---|
| `case.js` | WhatsApp command dispatcher: per-account prefix/settings/menu/owner, Pixel engine bridge, menu delivery (image + caption + buttons + fake status) |
| `pixel/engine.js` | The full `Pixel.js` command switch (682 commands) mounted as a library |
| `pixel/config.js` | Pixel defaults (globals: prefix, botname, ownername, mess…) |
| `pixel/lib/*` | Pixel helpers (`wa`, `myfunc`, `menu421`, `cards`, `converter`, `uploader`, …) |
| `pixel/database/` | `menu_list.json` seed (274 entries), banners, `_seed/` for per-account stores |
| `pixel/node_modules/` | Local compatibility shims — see below |
| `helper/scope.js` | Per-account data scoping (`database/accounts/<waNum>/`) |
| `helper/function.js` | Settings store, `menuStyle` + `Pixel X Ultra` branding migration |
| `economy.js`, `games.js` | Patched to read/write the per-account store |
| `dev-commands.js` | `eval`/`exec` removed from `DEV_CMDS` and neutered |
| `lib/menu421.js` | Pixel menu renderer (styles 1/2/3), unchanged |
| `index.js` | Optional: the panel/Telegram entry with the “💾 Paste Session ID” flow |
| `database/pixel_menu_list.json` | Pixel command list used by the menu and `pixelmenu` |

## Install

1. Stop the server.
2. Upload this tree over the server root (same paths).
3. Keep the existing `node_modules/`, `sessions/`, `database/settings.json` — do not replace them.
4. Start the server.

No npm install is required: every missing package is shimmed under `pixel/node_modules/`.

## Shims (why they exist)

The panel cannot install packages, so these are implemented locally:

- `moment-timezone` → Date-based subset (`format`, `tz`, `fromNow`)
- `fs-extra`, `performance-now`, `human-readable` → thin wrappers
- `google-tts-api` → builds the same `translate_tts` URL
- `@vitalets/google-translate-api` → calls `translate.googleapis.com`
- `node-webpmux` → pass-through (stickers send, custom EXIF is skipped)
- `@ffmpeg-installer/ffmpeg` → system `ffmpeg`
- `gifted-btns` → clean-room native-flow button sender (the published package is obfuscated + `eval`)

## Commands that are blocked

`eval`, `ev`, `$`, `npm`, `getsession`, `clearsession`, `backup`, `audiospeed` — code/shell execution and session-credential export. They appear in the menu (Pixel parity) but answer “disabled on this panel build”. `child_process` inside the engine throws.

## Notes

- Menu = one bubble: image header + 329-line caption + `OPEN REPO` / `PING` buttons, quoted against a fake `status@broadcast`.
- Boxed replies: `auto*`, `anti*`, `setmenu`, `settings`, `repo`/`script`. Everything else is plain bold-italic Pixel text.
- `update` only reports versions — it never overwrites files (the original self-update would have replaced `index.js` and broken panel/Telegram).
- Rollback: keep `case.js.pre-pixel.bak`, `index.js.pre-session.bak` and the `.pre-pixel.bak` copies of patched modules.
