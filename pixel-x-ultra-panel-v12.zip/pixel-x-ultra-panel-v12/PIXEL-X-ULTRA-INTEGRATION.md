# Pixel X Ultra — WhatsApp handler integration

Server: `Blacklord 👽` (`e1f8f78a-d8b1-4cfb-b4f0-cba67ec0af17`), node `CORTANA IS HERE`
Source integrated: `pixel-x-ultra-source-main/Pixel.js` (GitHub `blacklorddev15/Back`)
Deployed: `case.js` (31,080 B) + `pixel/` engine tree + `helper/function.js`

## 1. Command surface

| Layer | Count |
|---|---|
| Pixel command engine (full `Pixel.js` switch) | **682** registered |
| Dispatched to the engine | **674** |
| Blocked for security | **8** (below) |
| Per-account plumbing in `case.js` (menu, setmenu, setprefix, setbotname, mode, owner, premium, sticker-bind, ping, pixelmenu) | 33 |
| Legacy modules still routed for names Pixel does not define | 390 |

`case.js` parses the per-account prefix and hands every Pixel command to `pixel/engine.js`; commands Pixel does not define fall through to the pre-existing modules (`ai`, `economy`, `tools`, `stickers`, …).

## 2. Commands excluded (with reason)

| Command | Reason |
|---|---|
| `eval`, `ev` | Executes arbitrary JavaScript supplied in chat. Blocked in the dispatcher **and** in the engine guard. |
| `$` | Executes arbitrary shell commands. |
| `npm` | Runs `npm pack` on the host from chat. |
| `getsession` | Returns the account's WhatsApp session/credentials. |
| `clearsession` | Deletes stored pairing credentials. |
| `backup` | Zips session files (`zip backup.zip *`) — exports credentials. |
| `audiospeed` | Shell `ffmpeg` invocation; shell execution is disabled on this build. |

`child_process` inside the engine is replaced with a throwing stub, so even an unlisted code path cannot spawn a shell.

## 3. Commands changed for compatibility

Missing npm packages are provided as panel-local shims under `pixel/node_modules/` (no network install on the panel):

| Package | Shipped as | Behaviour |
|---|---|---|
| `moment-timezone` | Date-based shim | `tz()/format()/fromNow()` subset; date strings only, no tz database |
| `fs-extra` | fs wrappers | ensureDir/copy/move/remove/json helpers |
| `performance-now` | `perf_hooks` | exact |
| `google-tts-api` | URL builder | produces the same `translate_tts` URL, no package |
| `gifted-btns` | text fallback | native buttons/lists degrade to plain text listing |
| `node-webpmux` | pass-through | stickers send; custom EXIF/pack metadata is not written |
| `@vitalets/google-translate-api` | endpoint wrapper | uses `translate.googleapis.com`, same call shape |
| `human-readable` | formatter | byte-size formatting only |
| `@ffmpeg-installer/ffmpeg` | system `ffmpeg` | media conversion works only if the image provides `ffmpeg` |

Still unavailable (commands answer with a clear error instead of failing silently):

- `qrscan` — needs `jimp` + `jsqr`
- `setfullprofilepicture` — needs `jimp`

## 4. Branding and reply style

- Displayed name: **Pixel X Ultra** (`helper/function.js` default plus a one-time migration of the old `samsung`/`Pixel` value).
- Replying in Pixel's **bold-italic** font and quoting a **fake `status@broadcast`** preview with an embedded 140×140 thumbnail (`quote_thumb.jpg` → `pixelpic.jpg` fallback), matching `attachReplyFont()` / `statusQuote()` in `Pixel.js`.
- Menu styles 1/2/3 from `lib/menu421.js`, switchable per account with `setmenu`.
- Boxed card replies are limited to the `auto*`, `anti*`, `setmenu`, `settings` and `repo`/`script` families (`boxFamilyReply` in the engine, `replyCard` in the dispatcher). Every other reply is plain Pixel text — bold-italic, fake status quote, no box.
- Menu text: 329 lines / 274 entries / 9 sections, sent as blockquoted text (image only when the account sets `setmenuimg`).

## 5. Isolation model

- Settings: `database/settings.json`, keyed by WhatsApp number (prefix, menu style, bot name, menu image, mode, owner, toggles).
- Engine data: `pixel/database/accounts/<waNum>/` — the engine module is instantiated once per account so its path constants resolve to that tenant (`warnings`, `groups`, `owner`, `bot-settings`, sticker bindings).
- Economy/games stores: `database/accounts/<waNum>/` via `helper/scope.js`.
- Linked devices: `key.fromMe` messages dispatch as the bot's own number; `@lid` participants are resolved to a phone number before owner/admin checks.
- No command in the handler reads or transmits `sessions/` or `creds.json`.

## 6. Validation performed

`node --check` on every changed file, plus a stubbed harness (48 checks, all passing): three menu styles, per-account prefix isolation, separate economy stores per account, linked-device dispatch, self-mode gating, blocked commands, engine dispatch, styled replies with fake status quote, and no session-path leakage.

## 7. Known limitations

- Pixel installs its anti-edit listener on the socket; with several accounts on one process that listener binds to the first account loaded, so `antiedit` behaves as first-account-wins.
- Commands that depend on third-party APIs (downloads, AI, scraper endpoints) can fail on upstream errors; they surface a command-specific error rather than crashing.
- Native button/list payloads arrive as plain text (see `gifted-btns` shim).

## 8. Rollback

Previous files are on the server as `case.js.pre-pixel.bak`, `helper/function.js.pre-pixel.bak`, `economy.js.pre-pixel.bak`, `games.js.pre-pixel.bak`, `dev-commands.js.pre-pixel.bak`, plus the original `case.js.bak`. Removing `/pixel` and restoring `case.js.pre-pixel.bak` returns the panel to its previous state.
